#pragma once
template<typename T>
void quick_sort(T arr[], int low, int high);