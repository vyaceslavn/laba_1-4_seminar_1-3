#include "gtest/gtest.h"
#include "insertion_sort.h"
#include "selection_sort.h"
#include "exchange_sort.h"
#include "bubble_sort.h"
#include "optimized_bubble_sort.h"
#include "binary_insertion_sort.h"
#include "shaker_sort.h"
#include "shell_sort.h"
#include "quick_sort.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <string>


TEST(insertion_sortTest, SingleElement) {
    int arr[] = { 42 };
    insertion_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(insertion_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(insertion_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(insertion_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(insertion_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(insertion_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(selection_sortTest, SingleElement) {
    int arr[] = { 42 };
    selection_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(selection_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    selection_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(selection_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    selection_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(selection_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    selection_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(selection_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    selection_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(selection_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    selection_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(exchange_sortTest, SingleElement) {
    int arr[] = { 42 };
    exchange_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(exchange_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    exchange_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(exchange_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    exchange_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(exchange_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    exchange_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(exchange_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    exchange_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(exchange_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    exchange_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(bubble_sortTest, SingleElement) {
    int arr[] = { 42 };
    bubble_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(bubble_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(bubble_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(bubble_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(bubble_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(bubble_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(optimized_bubble_sortTest, SingleElement) {
    int arr[] = { 42 };
    optimized_bubble_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(optimized_bubble_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    optimized_bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(optimized_bubble_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    optimized_bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(optimized_bubble_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    optimized_bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(optimized_bubble_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    optimized_bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(optimized_bubble_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    optimized_bubble_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(binary_insertion_sortTest, SingleElement) {
    int arr[] = { 42 };
    binary_insertion_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(binary_insertion_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    binary_insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(binary_insertion_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    binary_insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(binary_insertion_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    binary_insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(binary_insertion_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    binary_insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(binary_insertion_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    binary_insertion_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(shaker_sortTest, SingleElement) {
    int arr[] = { 42 };
    shaker_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(shaker_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    shaker_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(shaker_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    shaker_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(shaker_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    shaker_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(shaker_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    shaker_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(shaker_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    shaker_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(shell_sortTest, SingleElement) {
    int arr[] = { 42 };
    shell_sort(arr, 1);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}

TEST(shell_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    shell_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(shell_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    shell_sort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(shell_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    shell_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(shell_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    shell_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(shell_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    shell_sort(arr, sizeof(arr) / sizeof(arr[0]));

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}
TEST(quick_sorttTest, SingleElement) {
    int arr[] = { 42 };
    quick_sort(arr, 0, 0);
    ASSERT_EQ(1, sizeof(arr) / sizeof(arr[0])) << "Array size changed!";
    EXPECT_EQ(42, arr[0]);
}
TEST(quick_sortTest, AlreadySorted) {
    int arr[] = { 1, 2, 3, 4, 5 };
    quick_sort(arr, 0, sizeof(arr) / sizeof(arr[0]) - 1);
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(quick_sortTest, ReverseOrder) {
    int arr[] = { 5, 4, 3, 2, 1 };
    quick_sort(arr, 0, sizeof(arr) / sizeof(arr[0]) - 1);
    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) {
        EXPECT_EQ(i + 1, arr[i]);
    }
}

TEST(quick_sortTest, RandomOrder) {
    int arr[] = { 3, 7, 9, 1, 8, 6, 2 };
    quick_sort(arr, 0, sizeof(arr) / sizeof(arr[0])-1);

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(quick_sortTest, ArrayWithNegativeNumbers) {
    int arr[] = { 3, -1, 2, -5, 0 };
    quick_sort(arr, 0, sizeof(arr) / sizeof(arr[0]) - 1);

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);
    }
}
TEST(quick_sortTest, DoubleArray) {
    int arr[] = { 3.1, -1.2, 2.0, -5.5, 0.0 };
    quick_sort(arr, 0, sizeof(arr) / sizeof(arr[0]) - 1);

    for (int i = 0; i < sizeof(arr) / sizeof(arr[0]) - 1; i++) {
        ASSERT_LE(arr[i], arr[i + 1]);

    }
}


int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}