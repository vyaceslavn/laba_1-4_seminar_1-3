#pragma once
template<typename T>
void two_phase_merge_sort(T arr[], int n);