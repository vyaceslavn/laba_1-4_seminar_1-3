#pragma once
template<typename T>
void shell_sort(T arr[], int n);