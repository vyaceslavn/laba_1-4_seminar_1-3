#pragma once
template<typename T>
void selection_sort(T arr[], int n);