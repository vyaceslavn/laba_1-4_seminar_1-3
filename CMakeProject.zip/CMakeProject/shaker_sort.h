#pragma once
template<typename T>
void shaker_sort(T arr[], int n);