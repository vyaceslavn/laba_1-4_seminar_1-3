#include "two_phase_merge_sort.h"
#include <string>

template<typename T>
void mergeFiles(const std::string& file1, const std::string& file2, const std::string& outputFile) {
    std::ifstream in1(file1), in2(file2);
    std::ofstream out(outputFile);

    T val1, val2;
    in1 >> val1;
    in2 >> val2;

    while (in1.good() && in2.good()) {
        if (val1 < val2) {
            out << val1 << ' ';
            in1 >> val1;
        }
        else {
            out << val2 << ' ';
            in2 >> val2;
        }
    }

    while (in1.good()) {
        out << val1 << ' ';
        in1 >> val1;
    }

    while (in2.good()) {
        out << val2 << ' ';
        in2 >> val2;
    }

    in1.close();
    in2.close();
    out.close();
}

template<typename T>
void splitFile(const std::string& inputFile, const std::string& outputFile1, const std::string& outputFile2) {
    std::ifstream in(inputFile);
    std::ofstream out1(outputFile1), out2(outputFile2);

    T val;
    bool toOut1 = true;

    while (in >> val) {
        if (toOut1) {
            out1 << val << ' ';
        }
        else {
            out2 << val << ' ';
        }
        toOut1 = !toOut1;
    }

    in.close();
    out1.close();
    out2.close();
}

template<typename T>
void two_phase_merge_sort(const std::string& inputFile, const std::string& outputFile) {
    std::string tempFile1 = "temp1.txt";
    std::string tempFile2 = "temp2.txt";

    splitFile<T>(inputFile, tempFile1, tempFile2);
    mergeFiles<T>(tempFile1, tempFile2, outputFile);

    remove(tempFile1.c_str());
    remove(tempFile2.c_str());
}

template void two_phase_merge_sort<int>(int[], int);
template void two_phase_merge_sort<double>(double[], int);