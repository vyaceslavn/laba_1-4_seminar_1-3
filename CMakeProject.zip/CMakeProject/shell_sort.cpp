#include "shell_sort.h"
#include <algorithm>
template <typename T>
void shell_sort(T* arr, int n) {
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; ++i) {
            T temp = arr[i];
            int j;
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                arr[j] = arr[j - gap];
            }
            arr[j] = temp;
        }
    }
}

template void shell_sort<int>(int[], int);
template void shell_sort<double>(double[], int);